"""FootGuard image analysis service."""
